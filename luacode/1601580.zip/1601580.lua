-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1601580)
addappid(228988)
--setManifestid(228988,"6645201662696499616")
addappid(228989)
addappid(228990)
--setManifestid(228990,"1829726630299308803")
addappid(1601581,0,"7372485e88b89813dc5250dca3be72fcfa499604514bea173703fbb7bac1f78f")
--setManifestid(1601581,"6694642185819303478")
addappid(2791500,0,"647f22682ffa05f21b1ea12779b04414782ddf4f2456565761b6ee0f863204ee")
--setManifestid(2791500,"62191551857984617")
addappid(1601582,0,"430c4ff745d427259e5934cada320f38cfadad961bdb56a35f4403f2ffeaea6b")
--setManifestid(1601582,"742568876558121323")
addappid(1601583,0,"be06bc27eb3b8e788a06bae787211c5e406cf846a3aeceffbac54475a447d036")
--setManifestid(1601583,"3503695293846071892")
addappid(2791490,0,"3f4b6f54645a56bc7991b93bed90155b81354f90e7fb4113e92ed9378980e36c")
--setManifestid(2791490,"5534266034783623960")