-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1335830)
addappid(1335831,0,"f2232a3bfcb5c7612c95312dfd25d89e6f0795121c0554e12b911b6f8d982e65")
--setManifestid(1335831,"294758923796167176")
addappid(1335832,0,"3415b4a91f32415894d413bde36a9241af420679c00e1b11fb96c0c8ad90dcbd")
--setManifestid(1335832,"1709224061293058221")