-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the official here: https://discord.gg/piracylords

addappid(1547000)
addappid(228990)
--setManifestid(228990,"1829726630299308803")
addappid(1547001,0,"625ab457b256e557dc28337fec8a01b39731624ee6008b92670ac977c2691806")
--setManifestid(1547001,"6814041191190748315")
addappid(1899671,0,"b7921da5e50d00b2238d0fe870a354cb572bc5d397955fef02a439103f62827b")
--setManifestid(1899671,"5718000260924391145")