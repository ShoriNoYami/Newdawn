addappid(2463620)
addappid(2463621,0,"afc4266296f920dad2d1de47710439808ce55edf96d67ad439cf729604870f2b")
--setManifestid(2463621,"3693865265656153595")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]