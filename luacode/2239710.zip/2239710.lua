addappid(2239710)
addappid(2239711,0,"b157624d7bd77e603f16902ecbb3c59596e83a552e4089ce119057efa9d2f0b4")
--setManifestid(2239711,"8074446487676139274")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]
