addappid(2288350)
addappid(2288351,0,"584b8f457ad0579c460b81cc7584871d2076e59040b8e355650051f39e5509f3")
addappid(2486845,0,"b5ec8393c1fa4a977d0dba88aff0281a930e0341190fa65158c6067f8836a309")
--setManifestid(2288351,"8954425886569925147")
--setManifestid(2486845,"9187613266433653033")




--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]