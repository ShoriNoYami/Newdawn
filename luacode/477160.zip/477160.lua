-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(477160)
addappid(477161,1,"8bc8773aa491fcab031c973d15bae81a5139cd9d28bdbe82776e9f39dba071d1")
--setManifestid(477161,"6402861719820014798",0)
addappid(477162,1,"3e1b0a746178eda39e69d130aac41e225a61f7777ccd8907b3b81f02918242ac")
--setManifestid(477162,"3788656093835144143",0)
addappid(477163,1,"48a9d63f348dcd848df0af0fe2eb01efddbb549c03d113bfca9d88015d8b6b7d")
--setManifestid(477163,"129240740414445083",0)
addappid(477164,1,"d05522bd5e3f6e7f6bc455253be55a9d3057b94b95da110d6365a246121a5fdc")
--setManifestid(477164,"803940719847356966",0)
addappid(477165,1,"91b02c0aecb8688c5844032fe30518f25ac754a1b32ca68c91a6021623d06ebd")
--setManifestid(477165,"1411043900457074403",0)
addappid(477166,1,"3efd94cbca4e47344be62115da0240c6b360356e1634b47f47dbbd82b4de329d")
--setManifestid(477166,"2111907740247976469",0)
addappid(632870,1,"292790c00ead9bdc3e2da82f59687f73b21c059eb0e98e3d6d55a9218b594ae9")
--setManifestid(632870,"6110178810839816362",0)
