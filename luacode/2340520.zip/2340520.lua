addappid(2340520)
addappid(2340521,0,"087fe8526494d1976a8829148eef69b423316b13c45a469e31a3fc5165a78824")
--setManifestid(2340521,"8861248399659548779")





--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]