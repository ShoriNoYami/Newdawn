-- Fetch from public repos for AppID: 2623190
-- Game: The Elder Scrolls IV: Oblivion Remastered
addappid(2623190)
addappid(2623191, 1, "35dc19b14e7481262176a54f0a9de8f9e76c3dcf493a26fa085ed999e684b5f7")

-- Set Manifest GIDs
--setManifestid(2623191, "8581416069319670994", 0)