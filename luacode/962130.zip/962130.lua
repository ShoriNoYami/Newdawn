-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(962130)
addappid(962131,1,"809ed5f98fa8a3d2c3636c33504157cf05fc683e1810d35e554d7976573a4424")
--setManifestid(962131,"1768200224774657340",0)
addappid(962134,1,"d8b1b4a7d68cf73a4aade13a9d230c6f1b7b397273cfad6b1a5713c631170002")
--setManifestid(962134,"5364155453177518539",0)
