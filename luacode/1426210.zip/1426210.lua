-- This lua file has been fetched from the bot VICTOR which is the exclusive property of Piracy Lords server.
-- Redistribution of VICTORs files is not allowed AT ALL
-- Join the offical here: https://discord.gg/piracylords

addappid(1426210)
addappid(228988)
--setManifestid(228988,"6645201662696499616")
addappid(228990)
--setManifestid(228990,"1829726630299308803")
addappid(1426211,0,"c450c44e032e27d0308cf864259fb2af91bcfc58401a0caf33bb8efba85bb323")
--setManifestid(1426211,"5290425664756095500")